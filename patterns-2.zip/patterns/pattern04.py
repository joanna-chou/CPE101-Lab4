# Lab 4
#
# Name: Joanna Chou
# Instructor: Sussan Einakian
# Section: 07

import driver

def letter(row, col):
	if (row == 0) or (row == 8):
		return "W"
	elif (row in range(3,6,1)) and (col in range(3,7,1)):
		return 'W'
	else:
		return 'S'

if __name__ == '__main__':
	driver.comparePatterns(letter)

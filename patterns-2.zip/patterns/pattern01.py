# Lab 4
#
# Name: Joanna Chou
# Instructor: Sussan Einakian
# Section: 07

import driver

def letter(row, col):
	if (row in range(0,20,2)) and (col in range(0,3,1)): 
		return 'L' 
	elif (row in range(1,21,2)) and (col in range(17,21,1)):
		return 'O'
	else:
		return 'G'

if __name__ == '__main__':
	driver.comparePatterns(letter)

# Lab 4
#
# Name: Joanna Chou
# Instructor: Sussan Einakian
# Section: 07

import driver

def letter(row, col):
	if (row in range(1,9) and row > col):
		return 'B'
	elif (row in range(9,12) and col <=10):
		return 'B'
	elif (row in range(12,20) and row > col):
		return 'B'
	else:
		return 'U'

if __name__ == '__main__':
	driver.comparePatterns(letter)
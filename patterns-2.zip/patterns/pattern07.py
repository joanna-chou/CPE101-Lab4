# Lab 4
#
# Name: Joanna Chou
# Instructor: Sussan Einakian
# Section: 07

import driver

def letter(row, col):
	if (row in range (4,6) and col in range(7,10)):
		return 'X'
	elif (row in range(2,6) and col in range (4,10)):
		return 'Y'
	elif (row in range(4,7) and col in range (7,13)):
		return 'B'
	if row == 10:
		return 'B'
	else:
		return 'K'
if __name__ == '__main__':
	driver.comparePatterns(letter)

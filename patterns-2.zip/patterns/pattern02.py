# Lab 4
#
# Name: Joanna Chou
# Instructor: Sussan Einakian
# Section: 07

import driver

def letter(row, col):
	if (row in range(0,10)):
		if (row in range(5,8) and col in range(5,11)):
			return 'M'
		else:
			return 'N'
	else:
		if (row in range(13,16) and col in range(5,11)):
			return 'M'
		else:
			return 'Z'

if __name__ == '__main__':
	driver.comparePatterns(letter)

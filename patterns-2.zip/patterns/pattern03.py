# Lab 4
#
# Name: Joanna Chou
# Instructor: Sussan Einakian
# Section: 07

import driver

def letter(row, col):
	if (col in range(0,10)):
			return 'D'
	else:
		return 'P'

if __name__ == '__main__':
	driver.comparePatterns(letter)

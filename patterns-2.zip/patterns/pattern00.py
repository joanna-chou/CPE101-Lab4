# Lab 4
#
# Name: Joanna Chou
# Instructor: Sussan Einakian
# Section: 07

import driver

def letter(row, col):
	return 'A'

if __name__ == '__main__':
	driver.comparePatterns(letter)
